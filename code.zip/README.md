# Projet-Master
Code pour le projet de master année académique 2020-2021 dont le sujet porte sur l'étude des techniques de string matching utilisant les opérations bit à bit sur les mots machines
